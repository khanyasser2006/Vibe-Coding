---
name: gsd-stats
description: "Display project statistics — phases, plans, requirements, git metrics, and timeline"
---

<objective>
Display comprehensive project statistics including phase progress, plan execution metrics, requirements completion, git history stats, and project timeline.
</objective>

<execution_context>
@~/.gemini/antigravity/gsd-core/workflows/stats.md
</execution_context>

<process>
Execute end-to-end.
</process>
